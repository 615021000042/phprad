<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * post_category_option_list Model Action
     * @return array
     */
	function post_category_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT name AS value,name AS label FROM category ORDER BY id";
		$arr = $db->rawQuery($sqltext);
		return $arr;
	}

	/**
     * post_author_option_list Model Action
     * @return array
     */
	function post_author_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT name AS value,name AS label FROM users ORDER BY id";
		$arr = $db->rawQuery($sqltext);
		return $arr;
	}

	/**
     * getcount_category Model Action
     * @return Value
     */
	function getcount_category(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM category";
		$val = $db->rawQueryValue($sqltext);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_post Model Action
     * @return Value
     */
	function getcount_post(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM post";
		$val = $db->rawQueryValue($sqltext);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_users Model Action
     * @return Value
     */
	function getcount_users(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM users";
		$val = $db->rawQueryValue($sqltext);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

}
