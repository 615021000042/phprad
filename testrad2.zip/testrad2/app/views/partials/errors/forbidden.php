
<div class="container">
	<div class="row justify-content-center">
		<div class="col-sm-8">
			<div style="margin:8% 0" class="card card-body">
				<div class="text-center">
					<h2 class="text-danger mb-2">Resource access  forbidden!</h2>
					<div class="text-muted"><small>Please contact system administrator for more information</small></div>
					<hr />
					<a href="<?php print_link(HOME_PAGE); ?>" class="btn btn-primary">Go to home page</a>
				</div>
			</div>
		</div>
	</div>
</div>