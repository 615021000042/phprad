<div class="container">
	<div class="card card-body">
		<h3 class="text-danger">You are not authorized to access this page!</h3>
		<div class="text-muted"><i>Please meet the system administrator for more information!</i></div>
		<hr />
		<div class="">
			<a href="<?php print_link(HOME_PAGE); ?>" class="btn btn-primary">Go to home page</a>
		</div>
	</div>
</div>
