<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
	public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-angellist "></i>'
		),
		
		array(
			'path' => 'category', 
			'label' => 'Category', 
			'icon' => '<i class="fa fa-cab "></i>'
		),
		
		array(
			'path' => 'post', 
			'label' => 'Post', 
			'icon' => ''
		),
		
		array(
			'path' => 'users', 
			'label' => 'Users', 
			'icon' => ''
		)
	);

	
	
	public static $name = array();

}